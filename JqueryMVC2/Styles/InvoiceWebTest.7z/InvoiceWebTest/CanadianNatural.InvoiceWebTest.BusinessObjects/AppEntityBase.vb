Public Class AppEntityBase
    Inherits CNRLBusinessEntity

#Region "Constructor/Destructor"

#End Region

#Region "Properties"

#End Region

#Region "Public Methods"

#End Region

#Region "Private/Protected Methods"

#End Region

End Class
