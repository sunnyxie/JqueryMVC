Imports OakLeaf.MM.Main.Business

Public Class AppRuleBase
    Inherits CNRLBusinessRule

#Region "Constructor/Destructor"

    Public Sub New(ByVal hostObject As ImmBusinessRuleHost)
        MyBase.New(hostObject)
    End Sub

#End Region

#Region "Properties"

#End Region

#Region "Public Methods"

#End Region

#Region "Private/Protected Methods"

#End Region

End Class
