Namespace Constants
    Public Class Values
        Public Const ApplicationKey As String = "ISTCO"
    End Class

    Public Class SecurityConstants
        ' Public Const OperationCreateNewWell As Integer = 101
    End Class
End Namespace
